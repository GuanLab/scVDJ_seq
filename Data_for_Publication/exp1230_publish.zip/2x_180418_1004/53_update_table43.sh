#!/bin/bash
# usage:   bash 53_update_table43.sh

echo "### $0 ###"   >> ./analysis.log.txt

##########################################################################################
OUTdir="./table53_edit43"
mkdir -p ${OUTdir}

OUTtxt=${OUTdir}/53_checked_manually.txt
echo -n > ${OUTtxt}

## edit_here_to_update ###################################################################
# "Cluster"
echo "Cluster" >> ${OUTtxt}                ### edit here #############################
echo "Cluster" >> ${OUTtxt}                ### edit here #############################
echo "ROW6.COL3.DV27_cluster2" >> ${OUTtxt}
echo "ROW10.COL6.DV32_cluster2" >> ${OUTtxt}
echo "ROW21.COL6.DV14_cluster1" >> ${OUTtxt}
echo "ROW21.COL6.DV14_cluster2" >> ${OUTtxt}
echo "ROW21.COL6.DV14_cluster3" >> ${OUTtxt}
echo "ROW36.COL9.DV14_cluster2" >> ${OUTtxt}
echo "ROW48.COL3.DV2_cluster2" >> ${OUTtxt}
echo "ROW200.COL1.DV1_cluster1" >> ${OUTtxt}
echo "ROW200.COL7.DV1_cluster1" >> ${OUTtxt}



# generate updated table #################################################################
OUTup=${OUTdir}/53_updated43_will_be_removed.txt
cat ${OUTtxt} | grep "ROW" > ${OUTup}

N53=$(cat ${OUTup} | wc -l )
echo "### ${N53} clusters in table53 will be removed in table55"  >> ./analysis.log.txt
echo "### ${N53} clusters in table53 will be removed in table55"

cat ${OUTup}                                                      >> ./analysis.log.txt
cat ${OUTup}

##########################################################################################
# BASH DONE